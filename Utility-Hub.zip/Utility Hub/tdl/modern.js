const form = document.querySelector('#task-form');
const tasklist = document.querySelector('.collection');
const clearbtn = document.querySelector('.clear-tasks');
const filter = document.querySelector('#filter');
const taskInput = document.querySelector('#task');
alert('This is a simple to-do list web application. To use it, simply add the tasks you want to add to your to-do list. You can also search the tasks you added using the filter tasks input bar')
loadEventListeners();
function loadEventListeners(){
    document.addEventListener('DOMContentLoaded', getTasks);
    form.addEventListener('submit', addtask);
    tasklist.addEventListener('click' , myfunc);
    clearbtn.addEventListener('click', cleartasks);
    filter.addEventListener('keyup', filtertasks);
}
function getTasks(){
    let tasks;
    if(localStorage.getItem('tasks') === null){
        tasks = [];
    }
    else{
        tasks = JSON.parse(localStorage.getItem('tasks'));
    }
        tasks.forEach(function(tasks){
        const li = document.createElement('li');
        li.className = 'collection-item';
        li.appendChild(document.createTextNode(tasks));
        const link = document.createElement('a');
        link.className = 'delete-item secondary-content';
        link.innerHTML = '<i class = "fa fa-remove"></i>';
        li.appendChild(link);
        tasklist.appendChild(li);
    });
}

function addtask(e) {
    if(taskInput.value === ''){
        alert('Add a task');
    }
    else{
    e.preventDefault();


const li = document.createElement('li');
li.className = 'collection-item';
li.appendChild(document.createTextNode(taskInput.value));

//creating the X icon
const link = document.createElement('a');
link.className = 'delete-item secondary-content';
link.innerHTML = '<i class = "fa fa-remove"></i>';
li.appendChild(link);
tasklist.appendChild(li);
//local storage stuff
storetaskinlocalstorage(taskInput.value);
taskInput.value = '';
e.preventDefault();
    }
}
//local storage add function
function storetaskinlocalstorage(task){
    let tasks;
    if(localStorage.getItem('tasks') === null){
        tasks = [];
    }
    else{
        tasks = JSON.parse(localStorage.getItem('tasks'));
    }
    tasks.push(task); 
    localStorage.setItem('tasks' , JSON.stringify(tasks));
}
function myfunc(e){

    if(e.target.parentElement.classList.contains('delete-item')){
        e.target.parentElement.parentElement.style.opacity = '0';
        setTimeout(function(){e.target.parentElement.parentElement.remove();} , 300);
        //Removing from localstorage
        removetaskfromls(e.target.parentElement.parentElement);
        }
}
function removetaskfromls(taskitem){
    let tasks;
    if(localStorage.getItem('tasks') === null){
        tasks = [];
    }
    else{
        tasks = JSON.parse(localStorage.getItem('tasks'));
    }
    tasks.forEach(function(task, index){
        if(taskitem.textContent === task){
            tasks.splice(index, 1);
        }
    });
    localStorage.setItem('tasks', JSON.stringify(tasks));
}
function cleartasks(){
   if(confirm('Are you sure?')){
       while(tasklist.firstChild){
       tasklist.removeChild(tasklist.firstChild);
       localStorage.clear();
        }
    }
}
function filtertasks(e){
    const text = e.target.value.toLowerCase();
    document.querySelectorAll('.collection-item').forEach(function(task){
        const item = task.firstChild.textContent;
        if(item.toLowerCase().indexOf(text) != -1){
            task.style.display = 'block';
        }
        else{
            task.style.display = 'none';
        }
    })
}