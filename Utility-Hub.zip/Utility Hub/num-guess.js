var guess = Math.floor((Math.random() * 10) + 1);
var input = document.getElementById("inputguess");
var submit = document.getElementById("submitguess");
var msg = document.querySelector(".message");
var restartbtn = document.querySelector("#game");
var tries = 0;
var stries;
var min=1;
var max=10;
var chances = 3;
var flag;
submit.addEventListener("click", function(){
        window.inputint = parseInt(input.value);
        //console.log(inputint);
        //console.log(typeof(inputint));
        if(flag == 1){
            setmsg("You already won the game dude. Press Restart to play again." , "black");
            input.style.borderColor="black";
        }
        else{
        if(isNaN(inputint) || inputint < min || inputint > max){
            setmsg("Value must be a number between 1 and 10" , "red");
        }
        else{
            //WIN
        tries++;
        if(guess === inputint){
            if(tries>1){
                stries = "tries";
            }
            else{
                stries = "try";
            }
            input.style.borderColor ="Green";
            flag=1;
            restartwin();
        }
        else{
            //LOSE
            if(guess != inputint){
                chances--;
                if(chances>0){
                if(chances>1){
                    stries ="tries";
                }
                else{
                    stries = "try";
                }
                input.style.borderColor="black";
                setmsg(`${inputint} is not the right number.` + "You still have " + chances +" " + stries, "red");
                }
                else{
                    restartlose();
                }
            }
        }
     }   
    }
})
function setmsg(mesg , color){
    msg.style.color = color;
    msg.textContent = mesg;
}
function restartlose(){
    setmsg(`Sorry brother! You lost. The correct answer was ${guess}. Press Restart to play again.` , "red")
    input.disabled = true;
    submit.disabled = true;
    var btn = document.createElement("Button");
    input.style.borderColor ="red";
    btn.innerHTML = "Restart";
    restartbtn.appendChild(btn);
    btn.addEventListener('click' , function(){
    flag = 0;
    input.disabled = false;
    submit.disabled = false;
    guess = Math.floor((Math.random() * 10) + 1);
    msg.innerHTML="";
    btn.remove();
    input.style.borderColor="black";
    chances=3;
    tries=0;
    })
}
function restartwin(){
    setmsg(`${inputint} is correct! You guessed it after ${tries} ${stries}. Press Restart to play again.` , "green")
    input.disabled = true;
    submit.disabled = true;
    var btn = document.createElement("Button");
    btn.innerHTML = "Restart";
    restartbtn.appendChild(btn);
    btn.addEventListener('click' , function(){
    flag = 0;
    input.disabled = false;
    submit.disabled = false;
    guess = Math.floor((Math.random() * 10) + 1);
    msg.innerHTML="";
    btn.remove();
    input.style.borderColor="black";
    chances=3;
    tries=0;
    })
}
console.log(guess);
