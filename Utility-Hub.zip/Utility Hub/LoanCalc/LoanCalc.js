//ALL THE FORMULAS WERE GOOGLE SEARCHED
document.getElementById('loan-form').addEventListener('submit', function(e){
    document.getElementById('results').style.display = 'none';
    document.getElementById('loading').style.display = 'block';
    setTimeout(calculate, 2000);
    e.preventDefault();
});
function calculate(){
    let amount = document.getElementById('amount');
    let interest = document.getElementById('interest');
    let years = document.getElementById('years');
    let monthlyPay = document.getElementById('monthly');
    let totalPay = document.getElementById('total-payment');
    let totalInterest = document.getElementById('total-interest');
    let amountValue = parseFloat(amount.value);
    let calcedInterest = parseFloat(interest.value)/ 100 / 12;
    let calcedPayments = parseFloat(years.value) * 12;
    let x = Math.pow(1 + calcedInterest, calcedPayments);
    let monthly = (amountValue* x * calcedInterest)/(x-1);
    if(isFinite(monthly)){
        monthlyPay.value = monthly.toFixed(2);
        totalPay.value = (monthly * calcedPayments).toFixed(2);
        totalInterest.value = ((monthly * calcedPayments) - amountValue).toFixed(2);
        document.getElementById('results').style.display = 'block';
        document.getElementById('loading').style.display = 'none';
    } else {
      showErorr('Please check your numbers');
    }
}

function showErorr(error){
    document.getElementById('loading').style.display = 'none';
    document.getElementById('results').style.display = 'none';

    window.errorDiv = document.createElement('div');
    errorDiv.style.opacity = 0;
    const card = document.querySelector('.card');
    const heading = document.querySelector('.heading');
    errorDiv.className = 'alert alert-danger';
    errorDiv.setAttribute("id", "error");
    errorDiv.appendChild(document.createTextNode(error));
    card.insertBefore(errorDiv, heading);
    var steps = 0;
    var timer = setInterval(function(){
        steps++;
        errorDiv.style.opacity =  0.05 * steps;
        if(steps >= 20){
            clearInterval(timer);
            timer = undefined;
        }
    }, 25)
    setTimeout(clearError, 3000);
}

function clearError(){
    errorDiv.remove();
    /*var steps = 20;
    var timer = setInterval(function(){
    steps--;
    errorDiv.style.opacity =  0.05 * steps;
    if(steps >= 20){
        clearInterval(timer);
        timer = undefined;
    }
  }, 25)*/
}
